#include <Wire.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <math.h>

// ANGER: DS18B20 pan temperature and MPU-6050 knife motion each sound separately.
// DS18B20 DATA -> D2; MPU SDA -> A4, SCL -> A5, AD0 -> GND (0x68).
// Passive piezo buzzer + -> D8, - -> GND.
const uint8_t ONE_WIRE_BUS = 2;
const uint8_t MPU_ADDR = 0x68;
const uint8_t BUZZER_PIN = 8;
const uint8_t LED_PIN = LED_BUILTIN;
const uint16_t TEMP_SOUND_HZ = 659;
const uint16_t MOTION_SOUND_HZ = 698;
const uint16_t SOUND_DURATION_MS = 180;
const float TEMP_ON_C = 30.0f;
const float TEMP_OFF_C = 29.0f;
const float KNIFE_MOTION_ON_G = 0.35f;
const float KNIFE_MOTION_OFF_G = 0.24f;
const unsigned long SAMPLE_INTERVAL_MS = 250;

struct SoundCue { uint16_t frequency; };
SoundCue soundQueue[8];
uint8_t soundHead = 0, soundTail = 0;
bool soundPlaying = false, ledPulseActive = false;
unsigned long soundStartedMs = 0, ledStartedMs = 0;

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature temperatures(&oneWire);
float baselineX = 0.0f, baselineY = 0.0f, baselineZ = 0.0f;
unsigned long lastSampleMs = 0;
bool mpuReady = false, panHot = false, knifeMoving = false;

void queueSensorSound(uint16_t frequency) {
  const uint8_t nextHead = (soundHead + 1) % 8;
  if (nextHead == soundTail) return;
  soundQueue[soundHead].frequency = frequency;
  soundHead = nextHead;
  digitalWrite(LED_PIN, HIGH);
  ledStartedMs = millis();
  ledPulseActive = true;
}

void serviceOutput() {
  const unsigned long now = millis();
  if (ledPulseActive && now - ledStartedMs >= SOUND_DURATION_MS) {
    digitalWrite(LED_PIN, LOW);
    ledPulseActive = false;
  }
  if (soundPlaying && now - soundStartedMs >= SOUND_DURATION_MS) {
    noTone(BUZZER_PIN);
    soundPlaying = false;
  }
  if (!soundPlaying && soundTail != soundHead) {
    const uint16_t frequency = soundQueue[soundTail].frequency;
    soundTail = (soundTail + 1) % 8;
    tone(BUZZER_PIN, frequency, SOUND_DURATION_MS);
    soundStartedMs = now;
    soundPlaying = true;
  }
}

bool writeRegister(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(value);
  return Wire.endTransmission(true) == 0;
}

bool readAcceleration(float &x, float &y, float &z) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(MPU_ADDR, (uint8_t)6, (uint8_t)true) != 6) return false;
  const uint8_t xh = Wire.read(), xl = Wire.read();
  const uint8_t yh = Wire.read(), yl = Wire.read();
  const uint8_t zh = Wire.read(), zl = Wire.read();
  x = (int16_t)(((uint16_t)xh << 8) | xl) / 16384.0f;
  y = (int16_t)(((uint16_t)yh << 8) | yl) / 16384.0f;
  z = (int16_t)(((uint16_t)zh << 8) | zl) / 16384.0f;
  return true;
}

bool calibrateMPU() {
  float sumX = 0.0f, sumY = 0.0f, sumZ = 0.0f;
  uint8_t valid = 0;
  Serial.println(F("Keep the knife-mounted MPU still for startup calibration."));
  for (uint8_t i = 0; i < 40; ++i) {
    float x, y, z;
    if (readAcceleration(x, y, z)) {
      sumX += x; sumY += y; sumZ += z; ++valid;
    }
    delay(20);
  }
  if (valid == 0) return false;
  baselineX = sumX / valid;
  baselineY = sumY / valid;
  baselineZ = sumZ / valid;
  return true;
}

void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  temperatures.begin();
  temperatures.setResolution(9);

  mpuReady = writeRegister(0x6B, 0x00) &&
             writeRegister(0x1C, 0x00) &&
             writeRegister(0x1A, 0x03);
  delay(100);
  if (mpuReady) mpuReady = calibrateMPU();

  Serial.println(F("CHEN / ANGER: temperature and knife motion have separate sounds."));
  Serial.println(F("Passive piezo buzzer: D8 to GND."));
  Serial.println(mpuReady ? F("MPU ready; DS18B20 on D2.")
                          : F("MPU unavailable; temperature trigger remains active."));
}

void loop() {
  serviceOutput();
  const unsigned long now = millis();
  if (now - lastSampleMs < SAMPLE_INTERVAL_MS) return;
  lastSampleMs = now;

  temperatures.requestTemperatures();
  const float temperatureC = temperatures.getTempCByIndex(0);
  if (temperatureC == DEVICE_DISCONNECTED_C) {
    if (panHot) Serial.println(F("Pan temperature sensor disconnected."));
    panHot = false;
  } else if (!panHot && temperatureC >= TEMP_ON_C) {
    panHot = true;
    Serial.println(F("PAN TEMPERATURE trigger."));
    queueSensorSound(TEMP_SOUND_HZ);
  } else if (panHot && temperatureC <= TEMP_OFF_C) {
    panHot = false;
    Serial.println(F("Pan temperature reset."));
  }

  float x = 0.0f, y = 0.0f, z = 0.0f;
  if (mpuReady && readAcceleration(x, y, z)) {
    float largest = fabs(x - baselineX);
    const float changeY = fabs(y - baselineY);
    const float changeZ = fabs(z - baselineZ);
    if (changeY > largest) largest = changeY;
    if (changeZ > largest) largest = changeZ;
    const float threshold = knifeMoving ? KNIFE_MOTION_OFF_G : KNIFE_MOTION_ON_G;
    const bool movingNow = largest >= threshold;
    if (movingNow != knifeMoving) {
      knifeMoving = movingNow;
      if (knifeMoving) {
        Serial.println(F("KNIFE MOTION trigger."));
        queueSensorSound(MOTION_SOUND_HZ);
      } else {
        Serial.println(F("Knife motion reset."));
      }
    }
  } else {
    knifeMoving = false;
  }

  if (temperatureC != DEVICE_DISCONNECTED_C) {
    Serial.print(F("Pan: ")); Serial.print(temperatureC, 1); Serial.print(F(" C"));
  } else {
    Serial.print(F("Pan: sensor error"));
  }
  Serial.print(F(" | knife motion: "));
  Serial.println(knifeMoving ? F("active") : F("inactive"));
  serviceOutput();
}

