#include <stdint.h>

// GREED: water level -> one sound; cutting-board pressure -> another.
// Water S -> A0, KEYES pressure S/SIG -> A1.
// Passive piezo buzzer + -> D8, - -> GND. Every sensor event is independent.
const uint8_t WATER_PIN = A0;
const uint8_t PRESSURE_PIN = A1;
const uint8_t BUZZER_PIN = 8;
const uint8_t LED_PIN = LED_BUILTIN;
const uint16_t WATER_SOUND_HZ = 523;
const uint16_t PRESSURE_SOUND_HZ = 587;
const uint16_t SOUND_DURATION_MS = 180;
const int WATER_ON_THRESHOLD = 250, WATER_OFF_THRESHOLD = 210;
const int PRESS_DELTA = 60;
const unsigned long SAMPLE_INTERVAL_MS = 100;

struct SoundCue { uint16_t frequency; };
SoundCue soundQueue[8];
uint8_t soundHead = 0, soundTail = 0;
bool soundPlaying = false, ledPulseActive = false;
unsigned long soundStartedMs = 0, ledStartedMs = 0;
unsigned long lastSampleMs = 0;
int pressureBaseline = 0;
bool waterActive = false, pressureActive = false;

void queueSensorSound(uint16_t frequency) {
  const uint8_t nextHead = (soundHead + 1) % 8;
  if (nextHead == soundTail) return;
  soundQueue[soundHead].frequency = frequency;
  soundHead = nextHead;
  digitalWrite(LED_PIN, HIGH);
  ledStartedMs = millis();
  ledPulseActive = true;
}

void serviceOutput() {
  const unsigned long now = millis();
  if (ledPulseActive && now - ledStartedMs >= SOUND_DURATION_MS) {
    digitalWrite(LED_PIN, LOW);
    ledPulseActive = false;
  }
  if (soundPlaying && now - soundStartedMs >= SOUND_DURATION_MS) {
    noTone(BUZZER_PIN);
    soundPlaying = false;
  }
  if (!soundPlaying && soundTail != soundHead) {
    const uint16_t frequency = soundQueue[soundTail].frequency;
    soundTail = (soundTail + 1) % 8;
    tone(BUZZER_PIN, frequency, SOUND_DURATION_MS);
    soundStartedMs = now;
    soundPlaying = true;
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(WATER_PIN, INPUT);
  pinMode(PRESSURE_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  delay(500);
  long total = 0;
  for (uint8_t i = 0; i < 16; ++i) {
    total += analogRead(PRESSURE_PIN);
    delay(10);
  }
  pressureBaseline = total / 16;
  Serial.println(F("TAN / GREED: water and pressure have separate sound events."));
  Serial.print(F("Pressure baseline: "));
  Serial.println(pressureBaseline);
  Serial.println(F("Connect a passive piezo between D8 and GND."));
  Serial.println(F("Calibrate WATER thresholds with dry and wet readings."));
}

void loop() {
  serviceOutput();
  const unsigned long now = millis();
  if (now - lastSampleMs < SAMPLE_INTERVAL_MS) return;
  lastSampleMs = now;

  const int water = analogRead(WATER_PIN);
  const int pressure = analogRead(PRESSURE_PIN);
  if (!waterActive && water >= WATER_ON_THRESHOLD) {
    waterActive = true;
    Serial.println(F("WATER LEVEL trigger."));
    queueSensorSound(WATER_SOUND_HZ);
  } else if (waterActive && water <= WATER_OFF_THRESHOLD) {
    waterActive = false;
    Serial.println(F("Water level reset."));
  }

  if (!pressureActive && pressure <= pressureBaseline - PRESS_DELTA) {
    pressureActive = true;
    Serial.println(F("CUTTING-BOARD PRESSURE trigger."));
    queueSensorSound(PRESSURE_SOUND_HZ);
  } else if (pressureActive && pressure >= pressureBaseline - PRESS_DELTA / 2) {
    pressureActive = false;
    Serial.println(F("Cutting-board pressure reset."));
  }

  Serial.print(F("Water ADC=")); Serial.print(water);
  Serial.print(waterActive ? F(" active") : F(" inactive"));
  Serial.print(F(" | Pressure ADC=")); Serial.print(pressure);
  Serial.println(pressureActive ? F(" pressed") : F(" released"));
  serviceOutput();
}

