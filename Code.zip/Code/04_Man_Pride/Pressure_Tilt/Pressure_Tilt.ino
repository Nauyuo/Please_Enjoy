#include <stdint.h>

// PRIDE: cutting-board pressure and salt-shaker tilt have separate sounds.
// KEYES pressure S/SIG -> A0; SW-520D bare switch -> D2 and GND.
// Passive piezo buzzer + -> D8, - -> GND.
const uint8_t PRESSURE_PIN = A0, TILT_PIN = 2;
const uint8_t BUZZER_PIN = 8, LED_PIN = LED_BUILTIN;
const uint16_t PRESSURE_SOUND_HZ = 988, TILT_SOUND_HZ = 1046;
const uint16_t SOUND_DURATION_MS = 180;
const int TILT_ACTIVE_STATE = LOW;
const int PRESS_DELTA = 60;
const unsigned long SAMPLE_INTERVAL_MS = 50, SWITCH_DEBOUNCE_MS = 30;

struct SoundCue { uint16_t frequency; };
SoundCue soundQueue[8];
uint8_t soundHead = 0, soundTail = 0;
bool soundPlaying = false, ledPulseActive = false;
unsigned long soundStartedMs = 0, ledStartedMs = 0;
unsigned long lastSampleMs = 0, switchChangedMs = 0;
int pressureBaseline = 0, lastRawSwitch = HIGH, stableSwitch = HIGH;
bool pressureActive = false, tiltActive = false;

void queueSensorSound(uint16_t frequency) {
  const uint8_t nextHead = (soundHead + 1) % 8;
  if (nextHead == soundTail) return;
  soundQueue[soundHead].frequency = frequency;
  soundHead = nextHead;
  digitalWrite(LED_PIN, HIGH);
  ledStartedMs = millis();
  ledPulseActive = true;
}

void serviceOutput() {
  const unsigned long now = millis();
  if (ledPulseActive && now - ledStartedMs >= SOUND_DURATION_MS) {
    digitalWrite(LED_PIN, LOW);
    ledPulseActive = false;
  }
  if (soundPlaying && now - soundStartedMs >= SOUND_DURATION_MS) {
    noTone(BUZZER_PIN);
    soundPlaying = false;
  }
  if (!soundPlaying && soundTail != soundHead) {
    const uint16_t frequency = soundQueue[soundTail].frequency;
    soundTail = (soundTail + 1) % 8;
    tone(BUZZER_PIN, frequency, SOUND_DURATION_MS);
    soundStartedMs = now;
    soundPlaying = true;
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(PRESSURE_PIN, INPUT);
  pinMode(TILT_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  delay(500);
  long total = 0;
  for (uint8_t i = 0; i < 16; ++i) {
    total += analogRead(PRESSURE_PIN);
    delay(10);
  }
  pressureBaseline = total / 16;
  Serial.println(F("MAN / PRIDE: pressure and salt-shaker tilt sound separately."));
  Serial.print(F("Unpressed pressure baseline: "));
  Serial.println(pressureBaseline);
  Serial.println(F("Passive piezo buzzer: D8 to GND."));
  Serial.println(F("Adjust TILT_ACTIVE_STATE if your module output is opposite."));
}

void loop() {
  serviceOutput();
  const unsigned long now = millis();
  const int rawSwitch = digitalRead(TILT_PIN);
  if (rawSwitch != lastRawSwitch) {
    lastRawSwitch = rawSwitch;
    switchChangedMs = now;
  }
  if (now - switchChangedMs >= SWITCH_DEBOUNCE_MS) stableSwitch = rawSwitch;
  const bool tilted = stableSwitch == TILT_ACTIVE_STATE;

  if (now - lastSampleMs < SAMPLE_INTERVAL_MS) return;
  lastSampleMs = now;
  const int pressure = analogRead(PRESSURE_PIN);
  const bool pressed = pressureActive
    ? pressure <= pressureBaseline - PRESS_DELTA / 2
    : pressure <= pressureBaseline - PRESS_DELTA;

  if (pressed != pressureActive) {
    pressureActive = pressed;
    if (pressureActive) {
      Serial.println(F("CUTTING-BOARD PRESSURE trigger."));
      queueSensorSound(PRESSURE_SOUND_HZ);
    } else {
      Serial.println(F("Cutting-board pressure reset."));
    }
  }
  if (tilted != tiltActive) {
    tiltActive = tilted;
    if (tiltActive) {
      Serial.println(F("SALT-SHAKER TILT trigger."));
      queueSensorSound(TILT_SOUND_HZ);
    } else {
      Serial.println(F("Salt-shaker tilt reset."));
    }
  }

  Serial.print(F("Pressure ADC="));
  Serial.print(pressure);
  Serial.print(pressed ? F(" pressed") : F(" released"));
  Serial.print(F(" | SW-520D="));
  Serial.println(tilted ? F("tilted") : F("inactive"));
  serviceOutput();
}

