#include <Wire.h>
#include <math.h>

// IGNORANCE: MPU stirring and humidity/steam DO each have a separate sound.
// Module AO -> A0, DO -> D2; MPU SDA=A4, SCL=A5, AD0 low -> 0x68.
// Passive piezo buzzer + -> D8, - -> GND.
const uint8_t HUMIDITY_AO_PIN = A0, HUMIDITY_DO_PIN = 2;
const uint8_t MPU_ADDR = 0x68, BUZZER_PIN = 8, LED_PIN = LED_BUILTIN;
const uint16_t MOTION_SOUND_HZ = 784, HUMIDITY_SOUND_HZ = 880;
const uint16_t SOUND_DURATION_MS = 180;
const int HUMIDITY_DO_ACTIVE_STATE = LOW;  // change to HIGH if this module is opposite
const float MOTION_ON_THRESHOLD_G = 0.30f;
const float MOTION_OFF_THRESHOLD_G = 0.22f;
const unsigned long SAMPLE_INTERVAL_MS = 100;

struct SoundCue { uint16_t frequency; };
SoundCue soundQueue[8];
uint8_t soundHead = 0, soundTail = 0;
bool soundPlaying = false, ledPulseActive = false;
unsigned long soundStartedMs = 0, ledStartedMs = 0;
unsigned long lastSampleMs = 0;
float baselineX = 0, baselineY = 0, baselineZ = 0;
bool mpuReady = false, motionActive = false, steamActive = false;

void queueSensorSound(uint16_t frequency) {
  const uint8_t nextHead = (soundHead + 1) % 8;
  if (nextHead == soundTail) return;
  soundQueue[soundHead].frequency = frequency;
  soundHead = nextHead;
  digitalWrite(LED_PIN, HIGH);
  ledStartedMs = millis();
  ledPulseActive = true;
}

void serviceOutput() {
  const unsigned long now = millis();
  if (ledPulseActive && now - ledStartedMs >= SOUND_DURATION_MS) {
    digitalWrite(LED_PIN, LOW);
    ledPulseActive = false;
  }
  if (soundPlaying && now - soundStartedMs >= SOUND_DURATION_MS) {
    noTone(BUZZER_PIN);
    soundPlaying = false;
  }
  if (!soundPlaying && soundTail != soundHead) {
    const uint16_t frequency = soundQueue[soundTail].frequency;
    soundTail = (soundTail + 1) % 8;
    tone(BUZZER_PIN, frequency, SOUND_DURATION_MS);
    soundStartedMs = now;
    soundPlaying = true;
  }
}

bool writeRegister(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(value);
  return Wire.endTransmission(true) == 0;
}

bool readAcceleration(float &x, float &y, float &z) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(MPU_ADDR, (uint8_t)6, (uint8_t)true) != 6) return false;
  const uint8_t xh = Wire.read(), xl = Wire.read();
  const uint8_t yh = Wire.read(), yl = Wire.read();
  const uint8_t zh = Wire.read(), zl = Wire.read();
  x = (int16_t)(((uint16_t)xh << 8) | xl) / 16384.0f;
  y = (int16_t)(((uint16_t)yh << 8) | yl) / 16384.0f;
  z = (int16_t)(((uint16_t)zh << 8) | zl) / 16384.0f;
  return true;
}

void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(HUMIDITY_AO_PIN, INPUT);
  pinMode(HUMIDITY_DO_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  mpuReady = writeRegister(0x6B, 0x00) &&
             writeRegister(0x1C, 0x00) &&
             writeRegister(0x1A, 0x03);
  delay(100);
  float sumX = 0, sumY = 0, sumZ = 0;
  uint8_t valid = 0;
  if (mpuReady) {
    for (uint8_t i = 0; i < 30; ++i) {
      float x, y, z;
      if (readAcceleration(x, y, z)) {
        sumX += x; sumY += y; sumZ += z; ++valid;
      }
      delay(20);
    }
  }
  if (valid == 0) {
    mpuReady = false;
  } else {
    baselineX = sumX / valid;
    baselineY = sumY / valid;
    baselineZ = sumZ / valid;
  }
  Serial.println(F("CHI / IGNORANCE: chopstick motion and steam have separate sounds."));
  Serial.println(mpuReady ? F("MPU ready; humidity AO=A0, DO=D2.")
                          : F("MPU unavailable; humidity input remains active."));
  Serial.println(F("Passive piezo buzzer: D8 to GND."));
  Serial.println(F("Keep chopsticks still during startup; adjust the module potentiometer."));
}

void loop() {
  serviceOutput();
  const unsigned long now = millis();
  if (now - lastSampleMs < SAMPLE_INTERVAL_MS) return;
  lastSampleMs = now;

  float x = 0, y = 0, z = 0;
  const bool haveAccel = mpuReady && readAcceleration(x, y, z);
  float largest = 0.0f;
  if (haveAccel) {
    largest = fabs(x - baselineX);
    const float deltaY = fabs(y - baselineY), deltaZ = fabs(z - baselineZ);
    if (deltaY > largest) largest = deltaY;
    if (deltaZ > largest) largest = deltaZ;
  }

  const int humidityAO = analogRead(HUMIDITY_AO_PIN);
  const int humidityDO = digitalRead(HUMIDITY_DO_PIN);
  const float motionThreshold = motionActive ? MOTION_OFF_THRESHOLD_G : MOTION_ON_THRESHOLD_G;
  const bool motionNow = haveAccel && largest >= motionThreshold;
  const bool steamNow = humidityDO == HUMIDITY_DO_ACTIVE_STATE;

  Serial.print(F("Humidity AO=")); Serial.print(humidityAO);
  Serial.print(F(" DO=")); Serial.print(humidityDO == HIGH ? F("HIGH") : F("LOW"));
  Serial.print(F(" | chopstick MPU delta=")); Serial.print(largest, 3); Serial.println(F(" g"));

  if (motionNow != motionActive) {
    motionActive = motionNow;
    if (motionActive) {
      Serial.println(F("CHOPSTICK STIR trigger."));
      queueSensorSound(MOTION_SOUND_HZ);
    } else {
      Serial.println(F("Chopstick motion reset."));
    }
  }
  if (steamNow != steamActive) {
    steamActive = steamNow;
    if (steamActive) {
      Serial.println(F("STEAM / HUMIDITY trigger."));
      queueSensorSound(HUMIDITY_SOUND_HZ);
    } else {
      Serial.println(F("Steam / humidity reset."));
    }
  }
  serviceOutput();
}

