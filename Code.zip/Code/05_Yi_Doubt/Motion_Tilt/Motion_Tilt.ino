#include <Wire.h>
#include <math.h>

// DOUBT: MPU chopstick stirring and SW-520D bowl tilt sound separately.
// MPU AD0 low -> 0x68; SDA=A4/SCL=A5. SW-520D -> D2 and GND.
// Passive piezo buzzer + -> D8, - -> GND.
const uint8_t MPU_ADDR = 0x68, TILT_PIN = 2;
const uint8_t BUZZER_PIN = 8, LED_PIN = LED_BUILTIN;
const uint16_t MOTION_SOUND_HZ = 1175, TILT_SOUND_HZ = 1319;
const uint16_t SOUND_DURATION_MS = 180;
const int TILT_ACTIVE_STATE = LOW;
const float MOTION_ON_THRESHOLD_G = 0.35f, MOTION_OFF_THRESHOLD_G = 0.25f;
const unsigned long SAMPLE_INTERVAL_MS = 50, SWITCH_DEBOUNCE_MS = 30;

struct SoundCue { uint16_t frequency; };
SoundCue soundQueue[8];
uint8_t soundHead = 0, soundTail = 0;
bool soundPlaying = false, ledPulseActive = false;
unsigned long soundStartedMs = 0, ledStartedMs = 0;
unsigned long lastSampleMs = 0, switchChangedMs = 0;
int lastRawSwitch = HIGH, stableSwitch = HIGH;
float baseX = 0, baseY = 0, baseZ = 0;
bool mpuReady = false, motionActive = false, tiltActive = false;

void queueSensorSound(uint16_t frequency) {
  const uint8_t nextHead = (soundHead + 1) % 8;
  if (nextHead == soundTail) return;
  soundQueue[soundHead].frequency = frequency;
  soundHead = nextHead;
  digitalWrite(LED_PIN, HIGH);
  ledStartedMs = millis();
  ledPulseActive = true;
}

void serviceOutput() {
  const unsigned long now = millis();
  if (ledPulseActive && now - ledStartedMs >= SOUND_DURATION_MS) {
    digitalWrite(LED_PIN, LOW);
    ledPulseActive = false;
  }
  if (soundPlaying && now - soundStartedMs >= SOUND_DURATION_MS) {
    noTone(BUZZER_PIN);
    soundPlaying = false;
  }
  if (!soundPlaying && soundTail != soundHead) {
    const uint16_t frequency = soundQueue[soundTail].frequency;
    soundTail = (soundTail + 1) % 8;
    tone(BUZZER_PIN, frequency, SOUND_DURATION_MS);
    soundStartedMs = now;
    soundPlaying = true;
  }
}

bool writeRegister(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(value);
  return Wire.endTransmission(true) == 0;
}

bool readAcceleration(float &x, float &y, float &z) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(MPU_ADDR, (uint8_t)6, (uint8_t)true) != 6) return false;
  const uint8_t xh = Wire.read(), xl = Wire.read();
  const uint8_t yh = Wire.read(), yl = Wire.read();
  const uint8_t zh = Wire.read(), zl = Wire.read();
  x = (int16_t)(((uint16_t)xh << 8) | xl) / 16384.0f;
  y = (int16_t)(((uint16_t)yh << 8) | yl) / 16384.0f;
  z = (int16_t)(((uint16_t)zh << 8) | zl) / 16384.0f;
  return true;
}

void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(TILT_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  mpuReady = writeRegister(0x6B, 0x00) &&
             writeRegister(0x1C, 0x00) &&
             writeRegister(0x1A, 0x03);
  delay(100);
  float sx = 0, sy = 0, sz = 0;
  uint8_t valid = 0;
  if (mpuReady) {
    for (uint8_t i = 0; i < 30; ++i) {
      float x, y, z;
      if (readAcceleration(x, y, z)) {
        sx += x; sy += y; sz += z; ++valid;
      }
      delay(20);
    }
  }
  if (valid == 0) {
    mpuReady = false;
  } else {
    baseX = sx / valid;
    baseY = sy / valid;
    baseZ = sz / valid;
  }
  Serial.println(F("YI / DOUBT: chopstick motion and bowl tilt sound separately."));
  Serial.println(F("Passive piezo buzzer: D8 to GND."));
  Serial.println(mpuReady ? F("MPU ready; keep chopsticks still during startup.")
                          : F("MPU unavailable; SW-520D input remains active."));
}

void loop() {
  serviceOutput();
  const unsigned long now = millis();
  const int rawSwitch = digitalRead(TILT_PIN);
  if (rawSwitch != lastRawSwitch) {
    lastRawSwitch = rawSwitch;
    switchChangedMs = now;
  }
  if (now - switchChangedMs >= SWITCH_DEBOUNCE_MS) stableSwitch = rawSwitch;
  const bool switchTilted = stableSwitch == TILT_ACTIVE_STATE;

  if (now - lastSampleMs < SAMPLE_INTERVAL_MS) return;
  lastSampleMs = now;

  float x = 0, y = 0, z = 0;
  const bool haveAccel = mpuReady && readAcceleration(x, y, z);
  float largest = 0;
  if (haveAccel) {
    largest = fabs(x - baseX);
    const float dy = fabs(y - baseY), dz = fabs(z - baseZ);
    if (dy > largest) largest = dy;
    if (dz > largest) largest = dz;
  }
  const float motionThreshold = motionActive ? MOTION_OFF_THRESHOLD_G : MOTION_ON_THRESHOLD_G;
  const bool motionNow = haveAccel && largest >= motionThreshold;
  if (motionNow != motionActive) {
    motionActive = motionNow;
    if (motionActive) {
      Serial.println(F("CHOPSTICK STIR trigger."));
      queueSensorSound(MOTION_SOUND_HZ);
    } else {
      Serial.println(F("Chopstick motion reset."));
    }
  }
  if (switchTilted != tiltActive) {
    tiltActive = switchTilted;
    if (tiltActive) {
      Serial.println(F("SMALL-BOWL TILT trigger."));
      queueSensorSound(TILT_SOUND_HZ);
    } else {
      Serial.println(F("Small-bowl tilt reset."));
    }
  }
  serviceOutput();
}

